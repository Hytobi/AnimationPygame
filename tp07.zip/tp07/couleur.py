#PLOUVIN Patrice
#21/11/2017
#Les couleurs du déssin


NOIR       = (  0,   0,   0)
BLANC      = (255, 255, 255)
BLEU_CIEL  = (119, 181, 254)
VERT       = (  0, 192,   0)
VERT_FONCE = (  0, 128,   0)
BEIGE      = (200, 173, 127)
MARRON     = (192, 128,  64)
ARDOISE    = ( 90,  94, 107)
ORANGE     = (255, 127,   0)
ROUGE_FEU  = (255,  73,   1)
JAUNE_OR   = (239, 216,   7)
JAUNE_CIT  = (247, 255,  60)
